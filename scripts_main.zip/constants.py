samples_names = {'h1n1': 'run230320_UVZ_BA_23-vsp-1337',
                 'h3n2': 'run230320_UVZ_BA_23-vsp-2129',
                 'rsv_a': 'run230320_UVZ_BA_23-vsp-1658',
                 'rsv_b': 'run230320_UVZ_BA_23-vsp-902',
                #  'victoria': 'run230320_UVZ_BA_23-vsp-2036',
                 'sars_cov_2_122': 'uvzsr-BA_24_00001-G12-BA_24_00000122',
                 'sars_cov_2_139': 'uvzsr-BA_24_00002-A09-BA_24_00000139',
                 'sars_cov_2_4964': 'run230710_UVZ_BA_23-vsp-4964'
                 }

virus_reference = {'h1n1': 'h1n1_2019',
                   'h3n2': 'h3n2_2021',
                   'rsv_a': 'rsv_a_2017',
                   'rsv_b': 'rsv_b_2019',
                   'sars_cov_2_122': 'sars_cov_2',
                   'sars_cov_2_139': 'sars_cov_2',
                   'sars_cov_2_4964': 'sars_cov_2'
                #    'victoria': 'victoria_2021',
                   }

mbs_consensus_names = {
                        'h1n1': 'run230320_UVZ_BA_23-vsp-1337_A__WISCONSIN__588__2019__H1N1_',
                        'h3n2': 'run230320_UVZ_BA_23-vsp-2129_A__DARWIN__6__2021__H3N2_',
                        'rsv_b': 'run230320_UVZ_BA_23-vsp-902_hRSV__B__Australia__VIC-RCH056__2019:EPI_ISL_1653999:2019-03-04', 
                        'sars_cov_2_122': 'Consensus_uvzsr-BA_24_00001-G12-BA_24_00000122_threshold_0.5_quality_20',  # mozno bude treba zmenit hlavicku v consenzus sekvencii pre sars_cov_2 a zjednotit s generovanymi vysledkami
                        'sars_cov_2_139': 'Consensus_uvzsr-BA_24_00002-A09-BA_24_00000139_threshold_0.5_quality_20',
                        'sars_cov_2_4964': 'run230710_UVZ_BA_23-vsp-4964_NC_045512.2',
                        'victoria': 'run230320_UVZ_BA_23-vsp-2036_B__AUSTRIA__1359417__2021__VICTORIA_', 
                        'rsv_a': 'run230320_UVZ_BA_23-vsp-1658_hRSV__A__England__397__2017:EPI_ISL_412866:2017-01-01'
                       }

samples_id = {'h1n1': '1337',
                 'h3n2': '2129',
                 'rsv_b': '902',
                 'victoria': '2036',
                 'rsv_a': '1658',
                 'sars_cov_2_122': '122',
                 'sars_cov_2_139': '139',
                 'sars_cov_2_4964': '4964'
                 }

mbs_consensus_path_dict = {
    'h1n1': './consensus_baseline/1337_consensus-h1n1_2019-wgs.fa',
    'h3n2': './consensus_baseline/2129_consensus-h3n2_2021-wgs.fa',
    'rsv_b': './consensus_baseline/902_consensus-rsv_b_2019-wgs.fa',
    'victoria': './consensus_baseline/2036_consensus-victoria_2021-wgs.fa',
    'rsv_a': './consensus_baseline/1658_consensus-rsv_a_2017-wgs.fa',
    'sars_cov_2_139': './consensus_baseline/139_consensus-sars_cov_2-wgs.fa',
    'sars_cov_2_122': './consensus_baseline/122_consensus-sars_cov_2-wgs.fa',
    'sars_cov_2_4964': './consensus_baseline/4964_consensus-sars_cov_2-wgs-respiratory.fa'
}

trimmers = ['trimmomatic', 'cutadapt']

tools_vc = ['bcftools', 'freebayes', 'ivar']

min_base_qualities = [0, 10, 13, 20]
min_map_qualities =  [0, 15, 30]
gap_fracs = [0.002, 0.05, 0.1]
redo_baqs = [0, 1]
adjust_mqs = [0, 25, 50]
ploidies = [1, 2]

params_variant_callers = {
   'freebayes': {'params_used': ['min_base_qualities', 'min_map_qualities', 'ploidies'], 
                 'min_base_qualities': min_base_qualities, 
                 'min_map_qualities': min_map_qualities, 
                 'ploidies': ploidies
                 },

    'bcftools': {'params_used': ['min_base_qualities', 'min_map_qualities', 'gap_fracs', 'redo_baqs', 'adjust_mqs', 'ploidies'],
                 'min_base_qualities': min_base_qualities, 
                 'min_map_qualities': min_map_qualities,
                 'gap_fracs': gap_fracs,
                 'redo_baqs': redo_baqs,
                 'adjust_mqs': adjust_mqs,
                 'ploidies': ploidies
                 },
    'ivar': {'params_used': ['min_base_qualities', 'min_map_qualities', 'redo_baqs'],
             'min_base_qualities': min_base_qualities, 
             'min_map_qualities': min_map_qualities,
             'redo_baqs': redo_baqs
             }
    }

mbs_set_params_variant_callers = {
    'freebayes': {
        'min_base_qualities': 20,
        'min_map_qualities': 15,
        'ploidies': 2
    },
    'bcftools': {
        'min_base_qualities': 13,
        'min_map_qualities': 0,
        'gap_fracs': 0.05,
        'redo_baqs': 1,
        'adjust_mqs': 50,
        'ploidies': 2
    },
    'ivar': {
        'min_base_qualities': 13,
        'min_map_qualities': 15,
        'redo_baqs': 0 # no-BAQ = 1
        }
}

param_abbr = {
    'min_base_qualities': 'minbq',
    'min_map_qualities': 'minmq',
    'gap_fracs': 'gap_frac',
    'redo_baqs': 'redo_baq',
    'adjust_mqs': 'adjust_mq',
    'redo_baqs': 'redo_baq',
    'ploidies': 'ploidy'
}
