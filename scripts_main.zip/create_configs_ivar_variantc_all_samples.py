import sys
from ruamel.yaml import RoundTripLoader, RoundTripDumper, load, dump

from constants import samples_names, virus_reference


variant_caller = 'ivar'

# Change parameters
def change_parameters_in_config(sample_name, virus, param_name, param_value):

    # read baseline config file, in which will be later set parameters to other values 
    path_to_config_file = "./scripts/variant_call/ivar_config.yaml"
    text_file = open(path_to_config_file, "r")
    #read whole file to a string
    data = text_file.read()
    #close file
    text_file.close()

    # set type: ruamel.yaml.comments.CommentedMap aby sa dalo prepisovat na spravnom mieste
    conf_file_baseline = load(data, Loader=RoundTripLoader)
    # dump(conf_file_baseline, sys.stdout, Dumper=RoundTripDumper)

    conf_file = conf_file_baseline

    # files names
    conf_file['samples'][0]['name'] = sample_name
    conf_file['samples'][0]['reference'] = virus_reference[virus]
    conf_file['report_dir'] = 'report/public/' + sample_name + '/'
    
    conf_file['consensus']['fasta'][param_name] = param_value
    
    # save to new yaml config file
    file_to_save = './scripts/variant_call/' + variant_caller + '_configs/' + sample_name + '_config.yaml'
    text_file = open(file_to_save, "w")
    text_file.write(str(dump(conf_file, Dumper=RoundTripDumper)))
    text_file.close()


# set parameters which will be USED
min_base_qualities = [0, 10, 13, 20]
min_map_qualities =  [0, 15, 30]
# ivar_frequency_threshold = [0.5]
# max_depths = ['8000']	
# min_depths = ['10']
no_BAQs = [True, False] # no-BAQ / no_base_alignment_quality def False (==>'redo_baq'(pri bcftools)=True) 


# iba nazov suboru bez pairend citani (koncoviek R1.gz/R2.gz)
for virus in samples_names:

    sample_name_prev = samples_names[virus]

    for min_base_quality in min_base_qualities:
        
        sample_name = sample_name_prev + '_' + variant_caller + '_minbq' + str(min_base_quality)

        # Change parameters
        change_parameters_in_config(sample_name, virus, 'min_base_quality', min_base_quality)

    
    for min_map_quality in min_map_qualities:
        
        sample_name = sample_name_prev + '_' + variant_caller + '_minmq' + str(min_map_quality) 
        
        change_parameters_in_config(sample_name, virus, 'min_mapping_quality', min_map_quality)

    for no_BAQ in no_BAQs:
        
        redo_baq = not no_BAQ
        redo_baq_str = int(redo_baq)
        sample_name = sample_name_prev + '_' + variant_caller + '_redo_baq' + str(redo_baq_str) 
        
        change_parameters_in_config(sample_name, virus, 'no_base_alignment_quality', no_BAQ)


    # create MBS: nastavenie parametrov s nastavenim hodnot na baseline hodnoty (MBS, ktore predtym boli vyhodnotene Mirom, ze su najlepsie)
    sample_name = sample_name_prev + '_' + variant_caller + '_baseline_params'

    # read baseline config file, in which will be later set parameters to other values 
    path_to_config_file = "./scripts/variant_call/ivar_config.yaml"
    text_file = open(path_to_config_file, "r")
    #read whole file to a string
    data = text_file.read()
    #close file
    text_file.close()

    # set type: ruamel.yaml.comments.CommentedMap aby sa dalo prepisovat na spravnom mieste
    conf_file_baseline = load(data, Loader=RoundTripLoader)
    # dump(conf_file_baseline, sys.stdout, Dumper=RoundTripDumper)
    
    conf_file = conf_file_baseline

    conf_file['samples'][0]['name'] = sample_name
    conf_file['samples'][0]['reference'] = virus_reference[virus]
    conf_file['report_dir'] = 'report/public/' + sample_name + '/'
    
    
    # save to new yaml config file
    file_to_save = './scripts/variant_call/' + variant_caller + '_configs/' + sample_name + '_config.yaml'
    text_file = open(file_to_save, "w")
    text_file.write(str(dump(conf_file, Dumper=RoundTripDumper)))
    text_file.close()
