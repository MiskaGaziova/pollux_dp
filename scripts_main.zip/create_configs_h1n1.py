import sys
from ruamel.yaml import RoundTripLoader, RoundTripDumper, load, dump

# read baseline config file, in which will be later set parameters to other values 

text_file = open("./scripts/variant_call/ivar.yaml", "r")

#read whole file to a string
data = text_file.read()
#close file
text_file.close()

# set type: ruamel.yaml.comments.CommentedMap aby sa dalo prepisovat na spravnom mieste
conf_file_baseline = load(data, Loader=RoundTripLoader)
dump(conf_file_baseline, sys.stdout, Dumper=RoundTripDumper)

# set parameters which will be uused
virus_reference = 'h1n1_2019'
trimmers = ['trimmomatic', 'cudapt']
trimmed_qualities = [10, 15, 20, 25, 30]
headcrops = [0, 5, 10, 15]
minlens = [35, 45, 55, 65]

# najdi nazov vzorky
# samples_results_df = samples_results_df.drop_duplicates('ID')
# samples_results_df_h3n2 = samples_results_df[samples_results_df['type'] == 'h3n2']
samples_results_df_h1n1 = ['run230403_UVZ_BA_23-vsp-3269']

# iba nazov suboru bez pairend citani (koncoviek R1.gz/R2.gz)
for sample_name_prev in samples_results_df_h1n1:
    for trimmer in trimmers:
        for trimmed_quality in trimmed_qualities:
            for headcrop in headcrops:
                for minlen in minlens:
                    
                    # paired end reads R1.gz and R2.gz
                    # for i in [1, 2]:
                        # report_dir aj sample_name

                    sample_name = sample_name_prev + '_' + trimmer + '_tripq' + str(trimmed_quality) + '_headcrop' + str(headcrop) + '_minlen' + str(minlen) # + '_R' + str(i) + '.fastq.gz'
                    
                    # copy of baseline file
                    conf_file = conf_file_baseline

                    # change parameters
                    conf_file['samples'][0]['name'] = sample_name
                    conf_file['samples'][0]['reference'] = virus_reference

                    conf_file['report_dir'] = 'report/public/' + sample_name
                    conf_file['reads']['preprocess']['trimmed']['method'] = trimmer
                    conf_file['reads']['preprocess']['trimmed']['quality'] = trimmed_quality

                    # save to new yaml config file
                    file_to_save = './scripts/variant_call/h1n1_configs/' + sample_name + '_ivar.yaml'
                    text_file = open(file_to_save, "w")
                    text_file.write(str(dump(conf_file, Dumper=RoundTripDumper)))
                    text_file.close()