import sys
from ruamel.yaml import RoundTripLoader, RoundTripDumper, load, dump

samples_names = {'h1n1': 'run230320_UVZ_BA_23-vsp-1337',
                 'h3n2': 'run230320_UVZ_BA_23-vsp-2129',
                 'rsv_a': 'run230320_UVZ_BA_23-vsp-1658',
                 'rsv_b': 'run230320_UVZ_BA_23-vsp-902',
                 'sars_cov_2_122': 'uvzsr-BA_24_00001-G12-BA_24_00000122',
                 'sars_cov_2_139': 'uvzsr-BA_24_00002-A09-BA_24_00000139',
                 'sars_cov_2_4964': 'run230710_UVZ_BA_23-vsp-4964'
                 }

virus_reference = {'h1n1': 'h1n1_2019',
                   'h3n2': 'h3n2_2021',
                   'rsv_a': 'rsv_a_2017',
                   'rsv_b': 'rsv_b_2019',
                   'sars_cov_2_122': 'sars_cov_2',
                   'sars_cov_2_139': 'sars_cov_2',
                   'sars_cov_2_4964': 'sars_cov_2'
                   }

variant_callers = ['bcftools', 'freebayes', 'ivar']

trimmers = ['trimmomatic', 'cutadapt']


for variant_caller in variant_callers:

    for trimmer in trimmers:
    
        # iba nazov suboru bez pairend citani (koncoviek R1.gz/R2.gz)
        for virus in samples_names.keys():
        
            sample_name_prev = samples_names[virus]
    
            # read baseline config file, in which will be later set parameters to other values
            config_path_name = "./scripts/variant_call/" + variant_caller + "_config_no_trimm_set.yaml"
            text_file = open(config_path_name, "r")
            #read whole file to a string
            data = text_file.read()
            #close file
            text_file.close()
            conf_file_baseline = load(data, Loader=RoundTripLoader)
            dump(conf_file_baseline, sys.stdout, Dumper=RoundTripDumper)
    
            
            sample_name = sample_name_prev + '_' + trimmer + '_' + variant_caller
                    
            # copy of baseline file
            conf_file = conf_file_baseline
            # change parameters
            conf_file['samples'][0]['name'] = sample_name
            conf_file['samples'][0]['reference'] = virus_reference[virus]
            conf_file['report_dir'] = 'report/public/' + sample_name + '/'
            conf_file['reads']['preprocess']['trimmed']['method'] = trimmer
            
            if trimmer == 'trimmomatic':
                conf_file['reads']['preprocess']['trimmed']['crop'] = 500
                conf_file['reads']['preprocess']['trimmed']['quality'] = 10
                conf_file['reads']['preprocess']['trimmed']['headcrop'] = 0
                conf_file['reads']['preprocess']['trimmed']['minlen'] = 35
            else:
                conf_file['reads']['preprocess']['trimmed']['minimum_length'] = 35
                q_cutoff = str(20) + ',' + str(20)
                conf_file['reads']['preprocess']['trimmed']['quality_cutoff'] = f'{(q_cutoff)}' # '"{}"'.format(q_cutoff)
                conf_file['reads']['preprocess']['trimmed']['length'] = 500
                conf_file['reads']['preprocess']['trimmed']['head_cut'] = 0
                conf_file['reads']['preprocess']['trimmed']['tail_cut'] = 0
            # save to new yaml config file
            file_to_save = './scripts/variant_call/final_comparison_configs/' + sample_name + '.yaml'
            text_file = open(file_to_save, "w")
            text_file.write(str(dump(conf_file, Dumper=RoundTripDumper)))
            text_file.close()
    