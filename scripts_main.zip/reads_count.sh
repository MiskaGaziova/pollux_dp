#!/bin/bash

# Array of sample names
samples=(
  "run230320_UVZ_BA_23-vsp-1337_R2"
  "run230320_UVZ_BA_23-vsp-2129_R2"
  "run230320_UVZ_BA_23-vsp-1658_R2"
  "run230320_UVZ_BA_23-vsp-902_R2"
  "uvzsr-BA_24_00001-G12-BA_24_00000122_R2"
  "uvzsr-BA_24_00002-A09-BA_24_00000139_R2"
  "run230710_UVZ_BA_23-vsp-4964_R2"
)

# Loop through each sample
for sample in "${samples[@]}"; do
  echo "Counting reads for $sample"
  # Initialize total count
  total_count=0
  # Find all fastq.gz files for the current sample and count reads
  for file in $(ls ${sample}*.fastq.gz 2> /dev/null); do
    echo "Processing file: $file"
    # Count the number of lines, divide by 4, and add to total count
    count=$(zcat $file | wc -l)
    let count/=4
    let total_count+=count
  done
  # Check if any files were found and counted
  if [ $total_count -eq 0 ]; then
    echo "No .fastq.gz files found for $sample"
    echo "No .fastq.gz files found for $sample" >> reads_count.txt
  else
    echo "Total reads for $sample: $total_count"
    echo "Total reads for $sample: $total_count" >> reads_count.txt
  fi
done
