import sys
from ruamel.yaml import RoundTripLoader, RoundTripDumper, load, dump

# read baseline config file, in which will be later set parameters to other values 
path_to_bs_configs = './scripts/generate_bs_bams/'
text_file = open(path_to_bs_configs + "map_config.yaml", "r")

#read whole file to a string
data = text_file.read()
#close file
text_file.close()

# set type: ruamel.yaml.comments.CommentedMap aby sa dalo prepisovat na spravnom mieste
conf_file_baseline = load(data, Loader=RoundTripLoader)
dump(conf_file_baseline, sys.stdout, Dumper=RoundTripDumper)



samples_names = {'h1n1': 'run230320_UVZ_BA_23-vsp-1337',
                 'h3n2': 'run230320_UVZ_BA_23-vsp-2129',
                 'rsv_b': 'run230320_UVZ_BA_23-vsp-902',
                 'victoria': 'run230320_UVZ_BA_23-vsp-2036',
                 'rsv_a': 'run230320_UVZ_BA_23-vsp-1658',
                  'sars_cov_2_122': 'uvzsr-BA_24_00001-G12-BA_24_00000122',
                  'sars_cov_2_139': 'uvzsr-BA_24_00002-A09-BA_24_00000139'
                 }

virus_sample_num = {'h1n1': '1337',
                 'h3n2': '2129',
                 'rsv_b': '902',
                 'victoria': '2036',
                 'rsv_a': '1658',
                  'sars_cov_2_139': '139',
                  'sars_cov_2_122': '122'
                 }

virus_reference = {'h1n1': 'h1n1_2019',
                   'h3n2': 'h3n2_2021', 
                   'rsv_b': 'rsv_b_2019', 
                   'sars_cov_2_139': 'sars_cov_2', 
                   'sars_cov_2_122': 'sars_cov_2', 
                   'victoria': 'victoria_2021', 
                   'rsv_a': 'rsv_a_2017'}


# iba nazov suboru bez pairend citani (koncoviek R1.gz/R2.gz)
for virus in samples_names.keys():
    
    print(virus)

    sample_name_prev = samples_names[virus]

    sample_name = sample_name_prev + '_bs'

    # copy of baseline file
    conf_file = conf_file_baseline
    # change parameters
    conf_file['samples'][0]['name'] = sample_name
    conf_file['samples'][0]['reference'] = virus_reference[virus]
    conf_file['report_dir'] = 'report/public/' + sample_name + '/'
    
    # save to new yaml config file
    # file_to_save = './scripts/variant_call/' + virus + '_' + virus_sample_num[virus] + '_cutadapt_configs/' + sample_name + '_ivar.yaml'
    file_to_save = path_to_bs_configs + sample_name + '_config.yaml'
    text_file = open(file_to_save, "w")
    text_file.write(str(dump(conf_file, Dumper=RoundTripDumper)))
    text_file.close()