import sys
from ruamel.yaml import RoundTripLoader, RoundTripDumper, load, dump


samples_names = {'h1n1': 'run230320_UVZ_BA_23-vsp-1337',
                 'h3n2': 'run230320_UVZ_BA_23-vsp-2129',
                 'rsv_b': 'run230320_UVZ_BA_23-vsp-902',
                 'victoria': 'run230320_UVZ_BA_23-vsp-2036',
                 'rsv_a': 'run230320_UVZ_BA_23-vsp-1658',
                 'sars_cov_2_122': 'uvzsr-BA_24_00001-G12-BA_24_00000122',
                 'sars_cov_2_139': 'uvzsr-BA_24_00002-A09-BA_24_00000139',
                 'sars_cov_2_4964': 'run230710_UVZ_BA_23-vsp-4964'
                 }

virus_reference = {'h1n1': 'h1n1_2019',
                   'h3n2': 'h3n2_2021',
                   'rsv_b': 'rsv_b_2019',
                   'sars_cov_2_122': 'sars_cov_2',
                   'sars_cov_2_139': 'sars_cov_2',
                   'sars_cov_2_4964': 'sars_cov_2',
                   'victoria': 'victoria_2021', 
                   'rsv_a': 'rsv_a_2017'}


variant_caller = 'bcftools'

# Change parameters
def change_parameters_in_config(sample_name, virus, param_name, param_value):

    # read baseline config file, in which will be later set parameters to other values 
    path_to_config_file = "./scripts/variant_call/" + variant_caller + "_config.yaml"
    text_file = open(path_to_config_file, "r")
    #read whole file to a string
    data = text_file.read()
    #close file
    text_file.close()

    # set type: ruamel.yaml.comments.CommentedMap aby sa dalo prepisovat na spravnom mieste
    conf_file_baseline = load(data, Loader=RoundTripLoader)

    # copy of baseline file
    conf_file = conf_file_baseline

    # files names
    conf_file['samples'][0]['name'] = sample_name
    conf_file['samples'][0]['reference'] = virus_reference[virus]
    conf_file['report_dir'] = 'report/public/' + sample_name + '/'
    
    conf_file['variant']['caller'][param_name] = param_value
    
    # save to new yaml config file
    file_to_save = './scripts/variant_call/' + variant_caller + '_configs/' + sample_name + '_config.yaml'
    text_file = open(file_to_save, "w")
    text_file.write(str(dump(conf_file, Dumper=RoundTripDumper)))
    text_file.close()


# set parameters which will be USED
min_base_qualities = [0, 10, 13, 20]
min_map_qualities =  [0, 15, 30]
gap_fracs = [0.002, 0.05, 0.1]
redo_baqs = [True, False]
adjust_mqs = [0, 25, 50]
ploidies = [True, False]

# iba nazov suboru bez pairend citani (koncoviek R1.gz/R2.gz)
for virus in samples_names:

    sample_name_prev = samples_names[virus]

    for min_base_quality in min_base_qualities:
        
        sample_name = sample_name_prev + '_' + variant_caller + '_minbq' + str(min_base_quality) 
        
        # Change parameters
        change_parameters_in_config(sample_name, virus, 'min_base_quality', min_base_quality)

    
    for min_map_quality in min_map_qualities:
        
        sample_name = sample_name_prev + '_' + variant_caller + '_minmq' + str(min_map_quality) 
        
        change_parameters_in_config(sample_name, virus, 'min_mapping_quality', min_map_quality)

    
    for ploidy in ploidies:

        if ploidy: # haploid
            ploidy_str = '1'
        else: # diploid
            ploidy_str = '2'

        sample_name = sample_name_prev + '_' + variant_caller + '_ploidy' + str(ploidy_str) 
        
        change_parameters_in_config(sample_name, virus, 'haploid', ploidy)
    
    
    for gap_frac in gap_fracs:
        
        sample_name = sample_name_prev + '_' + variant_caller + '_gap_frac' + str(gap_frac) 
        
        change_parameters_in_config(sample_name, virus, 'gap_frac', gap_frac)


    for redo_baq in redo_baqs:
        
        redo_baq_str = int(redo_baq)
        sample_name = sample_name_prev + '_' + variant_caller + '_redo_baq' + str(redo_baq_str) 
        
        change_parameters_in_config(sample_name, virus, 'redo_baq', redo_baq)


    for adjust_mq in adjust_mqs:
        
        sample_name = sample_name_prev + '_' + variant_caller + '_adjust_mq' + str(adjust_mq) 
        
        change_parameters_in_config(sample_name, virus, 'adjust_mq', adjust_mq)


    # create MBS: nastavenie parametrov s nastavenim hodnot na baseline hodnoty (MBS, ktore predtym boli vyhodnotene Mirom, ze su najlepsie)
    sample_name = sample_name_prev + '_' + variant_caller + '_baseline_params'

    # read baseline config file, in which will be later set parameters to other values 
    path_to_config_file = "./scripts/variant_call/" + variant_caller + "_config.yaml"
    text_file = open(path_to_config_file, "r")
    data = text_file.read()
    text_file.close()

    # set type: ruamel.yaml.comments.CommentedMap aby sa dalo prepisovat na spravnom mieste
    conf_file_baseline = load(data, Loader=RoundTripLoader)

    conf_file = conf_file_baseline

    conf_file['samples'][0]['name'] = sample_name
    conf_file['samples'][0]['reference'] = virus_reference[virus]
    conf_file['report_dir'] = 'report/public/' + sample_name + '/'
    
    
    # save to new yaml config file
    file_to_save = './scripts/variant_call/' + variant_caller + '_configs/' + sample_name + '_config.yaml'
    text_file = open(file_to_save, "w")
    text_file.write(str(dump(conf_file, Dumper=RoundTripDumper)))
    text_file.close()
