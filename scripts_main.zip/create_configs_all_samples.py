import sys
from ruamel.yaml import RoundTripLoader, RoundTripDumper, load, dump

# read baseline config file, in which will be later set parameters to other values 

text_file = open("./scripts/variant_call/trimmomatic_ivar.yaml", "r")

#read whole file to a string
data = text_file.read()
#close file
text_file.close()

# set type: ruamel.yaml.comments.CommentedMap aby sa dalo prepisovat na spravnom mieste
conf_file_baseline = load(data, Loader=RoundTripLoader)
dump(conf_file_baseline, sys.stdout, Dumper=RoundTripDumper)

samples_names = {'h1n1': 'run230320_UVZ_BA_23-vsp-1337',
                 'h3n2': 'run230320_UVZ_BA_23-vsp-2129',
                 'rsv_b': 'run230320_UVZ_BA_23-vsp-902', 
                #  'victoria': 'run230320_UVZ_BA_23-vsp-2036',
                 'rsv_a': 'run230320_UVZ_BA_23-vsp-1658',
                 'sars_cov_2_122': 'uvzsr-BA_24_00001-G12-BA_24_00000122',
                 'sars_cov_2_139':'uvzsr-BA_24_00002-A09-BA_24_00000139'
                 }

virus_references = {'h1n1': 'h1n1_2019',
                   'h3n2': 'h3n2_2021',
                   'rsv_b': 'rsv_b_2019',
                   'sars_cov_2_122': 'sars_cov_2',
                   'sars_cov_2_139': 'sars_cov_2',
                #    'victoria': 'victoria_2021',
                   'rsv_a': 'rsv_a_2017'}

# set parameters which will be used
trimmers = ['trimmomatic']
trimmed_qualities = [10, 15, 20, 25, 30]
headcrops = [15] #[0, 5, 10, 15]
minlens = [35, 45, 55, 65]


# iba nazov suboru bez pairend citani (koncoviek R1.gz/R2.gz)
for sample_name_prev in samples_names.keys():
    for trimmer in trimmers:
        for trimmed_quality in trimmed_qualities:
            for headcrop in headcrops:
                for minlen in minlens:

                    sample_name = samples_names[sample_name_prev] + '_' + trimmer + '_tripq' + str(trimmed_quality) + '_headcrop' + str(headcrop) + '_minlen' + str(minlen)
                    
                    # copy of baseline file
                    conf_file = conf_file_baseline

                    # change parameters
                    conf_file['samples'][0]['name'] = sample_name
                    conf_file['samples'][0]['reference'] = virus_references[sample_name_prev]

                    conf_file['report_dir'] = 'report/public/' + sample_name + '/'
                    conf_file['reads']['preprocess']['trimmed']['method'] = trimmer
                    conf_file['reads']['preprocess']['trimmed']['quality'] = trimmed_quality
                    conf_file['reads']['preprocess']['trimmed']['headcrop'] = headcrop
                    conf_file['reads']['preprocess']['trimmed']['minlen'] = minlen

                    # save to new yaml config file
                    file_to_save = './scripts/variant_call/trimmomatic_rest_configs/' + sample_name + '_ivar.yaml'
                    text_file = open(file_to_save, "w")
                    text_file.write(str(dump(conf_file, Dumper=RoundTripDumper)))
                    text_file.close()
