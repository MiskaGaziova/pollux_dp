import sys
from ruamel.yaml import RoundTripLoader, RoundTripDumper, load, dump

# read baseline config file, in which will be later set parameters to other values 

text_file = open("./scripts/variant_call/ivar_cutadapt.yaml", "r")

#read whole file to a string
data = text_file.read()
#close file
text_file.close()

# set type: ruamel.yaml.comments.CommentedMap aby sa dalo prepisovat na spravnom mieste
conf_file_baseline = load(data, Loader=RoundTripLoader)
dump(conf_file_baseline, sys.stdout, Dumper=RoundTripDumper)

# set parameters which will be uused
trimmers = ['cutadapt']
# trimmed_qualities = [ "15,15", "20,20", "25,25"] # [10, 15, 20, 25, 30]
trimmed_qualities = [10] #, 15, 20, 25, 30] 
headcrops = [0, 5] # 10, 15
minlens = [0, 35, 45, 55, 65]

# najdi nazov vzorky
# samples_results_df = samples_results_df.drop_duplicates('ID')

samples_names = {'h1n1': 'run230320_UVZ_BA_23-vsp-1337',
                 'h3n2': 'run230320_UVZ_BA_23-vsp-2129',
                 'rsv_b': 'run230320_UVZ_BA_23-vsp-902',
                 'victoria': 'run230320_UVZ_BA_23-vsp-2036',
                 'rsv_a': 'run230320_UVZ_BA_23-vsp-1658',
                #  'sars_cov_2': 'uvzsr-BA_24_00001-G12-BA_24_00000122'
                  'sars_cov_2': 'uvzsr-BA_24_00002-A09-BA_24_00000139'
                 }

virus_sample_num = {'h1n1': '1337',
                 'h3n2': '2129',
                 'rsv_b': '902',
                 'victoria': '2036',
                 'rsv_a': '1658',
                  'sars_cov_2': '139' # 122 / 139
                 }

virus_reference = {'h1n1': 'h1n1_2019',
                   'h3n2': 'h3n2_2021', 
                   'rsv_b': 'rsv_b_2019', 
                   'sars_cov_2': 'sars_cov_2', 
                   'victoria': 'victoria_2021', 
                   'rsv_a': 'rsv_a_2017'}


# iba nazov suboru bez pairend citani (koncoviek R1.gz/R2.gz)
for virus in samples_names:
    sample_name_prev = samples_names[virus]
    for trimmer in trimmers:
        for trimmed_quality in trimmed_qualities:
            for headcrop in headcrops:
                for minlen in minlens:
                    
                    # paired end reads R1.gz and R2.gz
                    # for i in [1, 2]:
                        # report_dir aj sample_name

                    sample_name = sample_name_prev + '_' + trimmer + '_tripq' + str(trimmed_quality) + '_headcrop' + str(headcrop) + '_minlen' + str(minlen)
                    # sample_name = sample_name_prev + '_' + trimmer + '_tripq' + trimmed_quality.split(',')[0] + '_headcrop' + str(headcrop) + '_minlen' + str(minlen)

                    # copy of baseline file
                    conf_file = conf_file_baseline

                    # change parameters
                    conf_file['samples'][0]['name'] = sample_name
                    conf_file['samples'][0]['reference'] = virus_reference[virus]

                    conf_file['report_dir'] = 'report/public/' + sample_name + '/'
                    conf_file['reads']['preprocess']['trimmed']['method'] = trimmer
                    # cutoff on 3' end ("20") or cutoff on both 5' and 3' ends "20,20"
                    q_cutoff = str(trimmed_quality) + ',' + str(trimmed_quality)
                    conf_file['reads']['preprocess']['trimmed']['quality_cutoff'] = f'{(q_cutoff)}' # '"{}"'.format(q_cutoff)
                    #conf_file['reads']['preprocess']['trimmed']['quality_cutoff'] = str(trimmed_quality.split(',')[0]) + ',' + str(trimmed_quality.split(',')[1]) #trimmed_quality
                    conf_file['reads']['preprocess']['trimmed']['head_cut'] = headcrop
                    conf_file['reads']['preprocess']['trimmed']['minimum_length'] = minlen

                    # save to new yaml config file
                    # file_to_save = './scripts/variant_call/' + virus + '_' + virus_sample_num[virus] + '_cutadapt_configs/' + sample_name + '_ivar.yaml'
                    file_to_save = './scripts/variant_call/cutadapt_q10_hc0_configs/' + sample_name + '_ivar.yaml'
                    text_file = open(file_to_save, "w")
                    text_file.write(str(dump(conf_file, Dumper=RoundTripDumper)))
                    text_file.close()
