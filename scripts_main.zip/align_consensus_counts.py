from Bio import pairwise2
from Bio.pairwise2 import format_alignment
import pandas as pd
from Bio import SeqIO
import json
import os
import numpy as np


def get_gap_mismatch_pairwise2_alignment(seqA, seqB):

    alignments = pairwise2.align.globalxx(seqA, seqB)

    # Print the alignment
    # print(format_alignment(*alignments[0]))

    # Extract the aligned sequences
    aligned_A = alignments[0][0]
    aligned_B = alignments[0][1]

    # Initialize counters for gaps and mismatches
    gap_count = 0
    mismatch_count = 0

    # Iterate through the aligned sequences to count gaps and mismatches
    for a, b in zip(aligned_A, aligned_B):
        if a == '-' or b == '-':
            gap_count += 1
        elif a != b:
            mismatch_count += 1

    # print("Gap Count:", gap_count)
    # print("Mismatch Count:", mismatch_count)

    n_count = str(seqB).count('N') # seqB.count('N')

    return {"score":alignments[0].score, "gaps": gap_count, "mismatches": mismatch_count, "N_count": n_count}


def get_scores_for_sample(virus, sample_consensus, mbs_consensus, mbs_consensus_name):
    
    score_metrics_dict = {}

    score_all_fragments = 0
    gaps_all_fragments = 0
    mismatch_all_fragments = 0
    n_count_all_fragments = 0

    # fragmenty pre vzorku
    for sample_fragment in sample_consensus.keys():
        
        fragment = sample_fragment.split('_')[-1] # skratka fragmentu genu

        # sekvencia (fragmentu) vzorky
        sample_consensus_seq = sample_consensus[sample_fragment].seq 
        
        # sekvencia (fragmentu) mbs
        if virus == 'rsv_a':
            mbs_consensus_seq = mbs_consensus[mbs_consensus_names[virus]].seq
        else:
            mbs_consensus_fragment = mbs_consensus_name + fragment
            mbs_consensus_seq = mbs_consensus[mbs_consensus_fragment].seq
        
        # prorovnanie consenzov (po fragmentoch), out: dict{score, gap, mismatch}; ulozenie do dict na poziciu fragmentu
        score_metrics_dict[fragment]  = get_gap_mismatch_pairwise2_alignment(mbs_consensus_seq, sample_consensus_seq)

        # cout scores for all fragments
        score_all_fragments += score_metrics_dict[fragment]['score']
        gaps_all_fragments += score_metrics_dict[fragment]['gaps']
        mismatch_all_fragments += score_metrics_dict[fragment]['mismatches']
        n_count_all_fragments += score_metrics_dict[fragment]['N_count']

    # pridaj parameter pre vsetky fragmenty (score = count cez vsetky fragmenty)
    score_metrics_dict['all_fragments'] = {'score': score_all_fragments, 'gaps': gaps_all_fragments, 'mismatches': mismatch_all_fragments, 'N_count':  n_count_all_fragments}

    return score_metrics_dict
        

# Porovnanie consenzov mbs_consenzus vs sample_consenzus

# mbs_consensus_names: pre kazdy virus nazov(id)
mbs_consensus_names = {'h1n1': 'run230320_UVZ_BA_23-vsp-1337_A__WISCONSIN__588__2019__H1N1_',
                       'h3n2': 'run230320_UVZ_BA_23-vsp-2129_A__DARWIN__6__2021__H3N2_',
                       'rsv_b': 'run230320_UVZ_BA_23-vsp-902_hRSV__B__Australia__VIC-', 
                       # 'sars_cov_2': '' 
                       'victoria': 'run230320_UVZ_BA_23-vsp-2036_B__AUSTRIA__1359417__2021__VICTORIA_',
                       'rsv_a': 'run230320_UVZ_BA_23-vsp-1658_hRSV__A__England__397__2017:EPI_ISL_412866:2017-01-01'
                       }

samples_names = {'h1n1': 'run230320_UVZ_BA_23-vsp-1337_',
                 'h3n2': 'run230320_UVZ_BA_23-vsp-2129_',
                 'rsv_b': 'run230403_UVZ_BA_23-vsp-3484_',
                 'sars_cov_2': 'run230403_UVZ_BA_23-vsp-3341_',
                 'victoria': 'run230522_UVZ_BA_23-vsp-4318_',
                 'rsv_a': 'run230320_UVZ_BA_23-vsp-1658_'
                 }

virus_reference = {'h1n1': 'h1n1_2019',
                   'h3n2': 'h3n2_2021', 
                   'rsv_b': 'rsv_b_209', 
                   'sars_cov_2': 'sars_cov_2_2020', 
                   'victoria': 'victoria_2021', 
                   'rsv_a': 'rsv_a_2017'}

parameteres_df = pd.read_csv('./data/parameters_set.tsv', sep='\t')

mbs_consensus_path_dict = {
    'h1n1': './consensus_baseline/1337_consensus-h1n1_2019-wgs.fa',
    'h3n2': './consensus_baseline/2129_consensus-h3n2_2021-wgs.fa',
    'rsv_b': './consensus_baseline/902_consensus-rsv_b_2019-wgs.fa',
    'victoria': './consensus_baseline/2036_consensus-victoria_2021-wgs.fa',
    'rsv_a': './consensus_baseline/1658_consensus-rsv_a_2017-wgs.fa'
}

samples_score_metrics_dict = {}


virus = 'h3n2'
consensus_baseline_path = mbs_consensus_path_dict[virus]

# nazov vzorky
for sample_id in [samples_names[virus]]:
    
    samples_score_metrics_parameter_dict = {}

    # cez vyber nastaveni respiracnej pipeliny
    for parameter in list(parameteres_df['parameters']):
        
        sample_name = sample_id + parameter
    
        consensus_sample_path = "./data/report_pollux/" + sample_name + "/_summary/consensus-" + virus_reference[virus] + "-wgs.fa"

        if os.path.exists(consensus_sample_path):

            mbs_consensus_name = mbs_consensus_names[virus]
            mbs_consensus = SeqIO.to_dict(SeqIO.parse(consensus_baseline_path, "fasta"))
            sample_consensus = SeqIO.to_dict(SeqIO.parse(consensus_sample_path, "fasta"))

            samples_score_metrics_parameter_dict[parameter] = get_scores_for_sample(virus, sample_consensus, mbs_consensus, mbs_consensus_name)

    samples_score_metrics_dict[sample_id] = samples_score_metrics_parameter_dict

# samples_score_metrics_dict


# uloz do jsonu
# path_to_save = './data/result_metrics/sample_' + samples_names[virus] + '_score_metrics.json'

# with open(path_to_save, 'w') as fp:
#     json.dump(samples_score_metrics_dict, fp)


# vytvor dataframe z jsonu
scores_colums = ['parameters', 'score', 'gap', 'mismatch', 'N_count', 'score_agg']
samples_score_metrics_parameter_df = pd.DataFrame(columns=scores_colums)

sample_name = [samples_names[virus]]

for parameter in list(samples_score_metrics_parameter_dict.keys()):  # samples_score_metrics_dict[sample]
    score =  samples_score_metrics_parameter_dict[parameter]['all_fragments']['score']
    gap = samples_score_metrics_parameter_dict[parameter]['all_fragments']['gaps']
    mismatch = samples_score_metrics_parameter_dict[parameter]['all_fragments']['mismatches']
    n_count = samples_score_metrics_parameter_dict[parameter]['all_fragments']['N_count']
    score_agg = score - gap - mismatch

    params_df = pd.DataFrame([[parameter, score, gap, mismatch, n_count, score_agg]], columns=scores_colums)

    samples_score_metrics_parameter_df = pd.concat([samples_score_metrics_parameter_df, params_df], axis=0, ignore_index=True)


# rozel 'parameter name' na viacero stlpcov
col_names_param = ['trimmer', 'quality', 'headcrop', 'minlen', 'score', 'gap', 'mismatch', 'N_count', 'score_agg']
scores_df = pd.DataFrame(columns=col_names_param)

for _, row in samples_score_metrics_parameter_df.iterrows():
    
    row_scores_df = pd.DataFrame([[np.nan, np.nan, np.nan, np.nan, row['score'], row['gap'], row['mismatch'], row['N_count'], row['score_agg']]],
                                   columns=col_names_param)
    param_name = row['parameters']
    
    row_scores_df['trimmer'] = param_name.split('_')[0]
    row_scores_df['quality'] = param_name.split('_')[1].replace('tripq', '')
    row_scores_df['headcrop'] = param_name.split('_')[2].replace('headcrop', '')
    row_scores_df['minlen'] = param_name.split('_')[3].replace('minlen', '')

    scores_df = pd.concat([scores_df, row_scores_df], axis=0, ignore_index=True)

# uloz do suboru
path_to_save = './data/result_metrics/' + virus + '/sample_' + samples_names[virus] + 'score_metrics_pairwise2.tsv'
scores_df.sort_values('score_agg', ascending=False).to_csv(path_to_save, sep='\t', index=False)
