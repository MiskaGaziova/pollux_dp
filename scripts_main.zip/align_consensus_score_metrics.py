import pandas as pd
from Bio import SeqIO
from Bio import pairwise2
from Bio.pairwise2 import format_alignment


def get_sequence(path_to_sqeuence, sequence_id):

    sequence_dict = SeqIO.to_dict(SeqIO.parse(path_to_sqeuence, "fasta"))

    if sequence_id in sequence_dict:
        sequence_data = sequence_dict[sequence_id].seq
        print("Sequence found:", sequence_data)
        return sequence_data
    else:
        print("Sequence not found.")
        return None


def get_alignment_metrics(align1, align2, score, begin, end): 
    s = [] 
    s.append("%s\n" % align1) 
    s.append(" " * begin) 
    gap=0
    mismatch=0
    for a, b in zip(align1[begin:end], align2[begin:end]): 
        if a == b: 
            s.append("|")  # match 
        elif a == "-" or b == "-": 
            s.append(" ")  # gap
            gap+=1
        else: 
            s.append(".")  # mismatch 
            mismatch+=1
    s.append("\n") 
    s.append("%s\n" % align2) 
    s.append("  Score=%g\n" % score)
    s.append("  Gap=%g\n" % gap)
    s.append("  Mismatch=%g\n" % mismatch)
    return {"score": score, "gap": gap, "mismatch": mismatch}
    

consensus_baseline_path = "./consensus_baseline/1337_consensus-h1n1_2019-wgs.fa"
consensus_sample_path = './data/h1n1_baseline_3269/consensus.fa'

# Porovnanie consenzov mbs_consenzus vs sample_consenzus
mbs_consensus_names = {'h1n1': 'run230320_UVZ_BA_23-vsp-1337_A__WISCONSIN__588__2019__H1N1_',
                       'h3n2': 'run230320_UVZ_BA_23-vsp-2129_A__DARWIN__6__2021__H3N2_',
                       'rsv_b': 'run230320_UVZ_BA_23-vsp-902_hRSV__B__Australia__VIC-', 
                       # 'sars_cov_2': '' 
                       'victoria': 'run230320_UVZ_BA_23-vsp-2036_B__AUSTRIA__1359417__2021__VICTORIA_'}

mbs_consensus_name = mbs_consensus_names['h1n1']  # 'run230320_UVZ_BA_23-vsp-1337_A__WISCONSIN__588__2019__H1N1_'
mbs_consensus = SeqIO.to_dict(SeqIO.parse(consensus_baseline_path, "fasta"))
sample_consensus = SeqIO.to_dict(SeqIO.parse(consensus_sample_path, "fasta"))

score_metrics_dict = {}


for sample_fragment in sample_consensus.keys():
    sample_consensus_seq = sample_consensus[sample_fragment].seq 
    fragment = sample_fragment.split('_')[-1] # skratka fragmentu genu
    mbs_consensus_fragment = mbs_consensus_name + fragment
    mbs_consensus_seq = mbs_consensus[mbs_consensus_fragment].seq
    print(fragment, sample_fragment, mbs_consensus_fragment)
    # print(mbs_consensus_seq, sample_consensus_seq)

    # prorovnanie consenzov (po fragmentoch)
    alignments = pairwise2.align.globalxx(mbs_consensus_seq, sample_consensus_seq)
    print(fragment, len(alignments))
    
    # hladaj najvacsie skore
    max_alignment_score = 0
    max_alignment_score_num = 0
    i = 0
    for alignment in alignments: 
        if max_alignment_score < alignment.score:
            max_alignment_score = alignment.score
            max_alignment_score_num = i
        i += 1
    
    # print(max_alignment_score_num, get_alignment_metrics(*alignments[max_alignment_score_num])) # alignments[0]
    score_metrics_dict[fragment]  = get_alignment_metrics(*alignments[0])

    score_metrics_dict
