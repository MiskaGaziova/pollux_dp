import pandas as pd


col_names = ['fragment_name', 'n_count']

mbs_consensus_paths_dict = {

    'rsv_b': '902_consensus-rsv_b_2019-wgs.fa',
    'h1n1': '1337_consensus-h1n1_2019-wgs.fa',
    'rsv_a': '1658_consensus-rsv_a_2017-wgs.fa',
    'victoria': '2036_consensus-victoria_2021-wgs.fa',
    'h3n2': '2192_consensus-h3n2_2021-wgs.fa'
}

all_virus_n_count_df = pd.DataFrame(columns=col_names)

for virus_mbs_path in mbs_consensus_paths_dict.keys():

    cons_path = './consensus_baseline/' + mbs_consensus_paths_dict[virus_mbs_path]
    cons_dict = SeqIO.to_dict(SeqIO.parse(cons_path, "fasta"))
    
    print(virus_mbs_path)

    n_count_list = list()
    for fragment in cons_dict.keys():
        n_count_list.append(cons_dict[fragment].seq.count('N'))
        fragment_name = fragment.split('_')[-2] + '_' + fragment.split('_')[-2]

        fragment_n_count_df = pd.DataFrame([[fragment_name, cons_dict[fragment].seq.count('N')]], columns=col_names)
        all_virus_n_count_df = pd.concat([all_virus_n_count_df, fragment_n_count_df], ignore_index=True)
    
    # print(n_count_list)
# all_virus_n_count_df

all_virus_n_count_df.to_csv('./consensus_baseline/virus_fragment_n_count.tsv', sep='\t', index=False)
