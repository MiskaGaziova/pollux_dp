import os


samples_names = {'h1n1': 'run230320_UVZ_BA_23-vsp-1337',
                 'h3n2': 'run230320_UVZ_BA_23-vsp-2129',
                 'rsv_a': 'run230320_UVZ_BA_23-vsp-1658',
                 'rsv_b': 'run230320_UVZ_BA_23-vsp-902',
                 'sars_cov_2_122': 'uvzsr-BA_24_00001-G12-BA_24_00000122',
                 'sars_cov_2_139': 'uvzsr-BA_24_00002-A09-BA_24_00000139',
                 'sars_cov_2_4964': 'run230710_UVZ_BA_23-vsp-4964'
                 }

variant_callers = ['bcftools', 'freebayes', 'ivar']
trimmers = ['trimmomatic', 'cutadapt']

# iba nazov suboru bez pairend citani (koncoviek R1.gz/R2.gz)
for sample_name_prev in samples_names.keys():
    sample_name_prev = samples_names[sample_name_prev]

    sample_name_prev = '/data/projects/pollux/reads/original/' + sample_name_prev
    print(sample_name_prev)

    for variant_caller in variant_callers:

        for trimmer in trimmers:

                    # paired end reads
                    for i in [1, 2]:
                        sample_name = sample_name_prev + '_' + trimmer + '_' + variant_caller +'_R' + str(i) + '.fastq.gz'

                        if '4964' in sample_name_prev:
                            sample_file_name_prev = sample_name_prev + '_reduced_reads_R' + str(i) + '.fastq.gz'
                        
                        else:
                            sample_file_name_prev = sample_name_prev + '_R' + str(i) + '.fastq.gz'
                        
                        if os.path.exists(sample_name):
                            print("File exists: ", sample_name)
                        else:
                            os.symlink(sample_file_name_prev, sample_name)
                            #print(sample_file_name_prev)
