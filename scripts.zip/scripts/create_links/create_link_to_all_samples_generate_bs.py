import os


samples_names = {'h1n1': 'run230320_UVZ_BA_23-vsp-1337',
                 'h3n2': 'run230320_UVZ_BA_23-vsp-2129',
                 'rsv_b': 'run230320_UVZ_BA_23-vsp-902',
                 'victoria': 'run230320_UVZ_BA_23-vsp-2036',
                 'rsv_a': 'run230320_UVZ_BA_23-vsp-1658',
                 'sars_cov_2_122': 'uvzsr-BA_24_00001-G12-BA_24_00000122',
                 'sars_cov_2_139': 'uvzsr-BA_24_00002-A09-BA_24_00000139'
                 }

virus_sample_num = {'h1n1': '1337',
                 'h3n2': '2129',
                 'rsv_b': '902',
                 'victoria': '2036',
                 'rsv_a': '1658',
                  'sars_cov_2_122': '122',
                   'sars_cov_2_139': '139'
                 }

virus_reference = {'h1n1': 'h1n1_2019',
                   'h3n2': 'h3n2_2021',
                   'rsv_b': 'rsv_b_2019',
                   'sars_cov_2_122': 'sars_cov_2',
                   'sars_cov_2_139': 'sars_cov_2',
                   'victoria': 'victoria_2021', 
                   'rsv_a': 'rsv_a_2017'}


# iba nazov suboru bez pairend citani (koncoviek R1.gz/R2.gz)
for virus in samples_names.keys():
    sample_name_prev = samples_names[virus]

    for i in [1, 2]: # paired end reads
        sample_name = sample_name_prev + '_bs_R' + str(i) + '.fastq.gz'
        sample_file_name_prev = sample_name_prev + '_R' + str(i) + '.fastq.gz'

        if os.path.exists(sample_name):
            print("File exists: ", sample_name)
        else:
            os.symlink(sample_file_name_prev, sample_name)
