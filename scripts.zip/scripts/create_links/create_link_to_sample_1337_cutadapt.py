import os


trimmers = ['cutadapt']
trimmed_qualities = [10, 15, 20, 25, 30]
headcrops = [0, 5, 10, 15]
minlens = [35, 45, 55, 65]

# iba nazov suboru bez pairend citani (koncoviek R1.gz/R2.gz)
for sample_name_prev in ['run230320_UVZ_BA_23-vsp-1337']: # samples_results_df['sample_name_prev']:
    print(sample_name_prev)
    for trimmer in trimmers:
        for trimmed_quality in trimmed_qualities:
            for headcrop in headcrops:
                for minlen in minlens:
                    
                    # paired end reads
                    for i in [1, 2]:
                        sample_name = sample_name_prev + '_' + trimmer + '_tripq' + str(trimmed_quality) + '_headcrop' + str(headcrop) + '_minlen' + str(minlen) + '_R' + str(i) + '.fastq.gz'
                        
                        # sample_file_names_opt = pd.concat([sample_file_names_opt, pd.DataFrame([[sample_name]], columns=['sample_name'])], ignore_index=True)

                        sample_file_name_prev = sample_name_prev + '_R' + str(i) + '.fastq.gz'
                       # print(sample_file_name_prev, sample_name)
                        os.symlink(sample_file_name_prev, sample_name)
