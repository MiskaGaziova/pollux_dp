import os


samples_names = {'h1n1': 'run230320_UVZ_BA_23-vsp-1337',
                 'h3n2': 'run230320_UVZ_BA_23-vsp-2129',
                 'rsv_b': 'run230320_UVZ_BA_23-vsp-902',
                 'victoria': 'run230320_UVZ_BA_23-vsp-2036',
                 'rsv_a': 'run230320_UVZ_BA_23-vsp-1658',
                 'sars_cov_2_122': 'uvzsr-BA_24_00001-G12-BA_24_00000122',
                 'sars_cov_2_139': 'uvzsr-BA_24_00002-A09-BA_24_00000139',
                 'sars_cov_2_4964': 'run230710_UVZ_BA_23-vsp-4964'
                 }

virus_reference = {'h1n1': 'h1n1_2019',
                   'h3n2': 'h3n2_2021',
                   'rsv_b': 'rsv_b_2019',
                   'sars_cov_2_122': 'sars_cov_2',
                   'sars_cov_2_139': 'sars_cov_2',
                   'sars_cov_2_4964': 'sars_cov_2',
                   'victoria': 'victoria_2021', 
                   'rsv_a': 'rsv_a_2017'}

variant_caller = 'freebayes'

def create_link(sample_name_prev, param_name, param_value):
    
    for i in [1, 2]:
        
        sample_name = sample_name_prev + '_' + variant_caller + param_name + str(param_value) + '_R' + str(i) + '.fastq.gz'

        if os.path.exists(sample_name):
            print("File exists: ", sample_name)
        
        else:
            sample_file_name_prev = sample_name_prev + '_R' + str(i) + '.fastq.gz'
            os.symlink(sample_file_name_prev, sample_name)
            print(sample_name)


# set parameters which will be USED
min_base_qualities =  [0, 10, 13, 20]
min_map_qualities = [0, 15, 30]
ploidies = [1, 2]


# iba nazov suboru bez pairend citani (koncoviek R1.gz/R2.gz)
for virus in samples_names:

    sample_name_prev = '/data/projects/pollux/reads/original/' + samples_names[virus]

    for min_base_quality in min_base_qualities:
        
        create_link(sample_name_prev, '_minbq', min_base_quality)


    for min_map_quality in min_map_qualities:
        
        create_link(sample_name_prev, '_minmq', min_map_quality)


    for ploidy in ploidies:

        create_link(sample_name_prev, '_ploidy', ploidy)

    # create for MBS config
    create_link(sample_name_prev, '_baseline', '_params')
